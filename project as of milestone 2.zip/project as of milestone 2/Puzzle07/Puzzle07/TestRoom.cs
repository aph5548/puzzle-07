﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
/*Alex Hecht
 * Section 2
 * Room for testing
 * */
namespace Puzzle07
{
    class TestRoom:Room
    {
        //IMPORTANT: this room is ONLY for testing other rooms to ensure they don't break the game- it will NEVER appear in Room Generation unless the room number is changed
        public TestRoom(int x, int y, int wid, int high, Texture2D text, int num) : base(x, y, wid, high, text, 0)
        {
        }



        //in addition, individual room classes will contian method specific to that room (ie specific objects and logic to allow room to function)
    }
}
