﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
/*Alex Hecht
 * Section 2
 * Room parent code
 * */
namespace Puzzle07
{
    class Room
    {
        //value to directly store the texture of the room
        Texture2D roomText;
        //rectangle to represent the actual room
        Rectangle roomActual;
        //a number, allowing the room to be referenced directly, to prevent repeats
        int roomNum;

        //constructor for the room, to set width, height, position, the texture, and its number
        //IMPORTANT: number should be based on the TYPE OF THE ROOM(ie each puzzle variation will have 1 room, each room will have a unique #) to ensure that the random generator does not produce the same type of puzzle twice in a run
        public Room(int x, int y, int wid, int high, Texture2D text, int num)
        {
            roomActual = new Rectangle();

            roomActual.Width = wid;
            roomActual.Height = high;

            roomActual.X = x;
            roomActual.Y = y;

            roomText = text;

            roomNum = num;

        }
    }
}
