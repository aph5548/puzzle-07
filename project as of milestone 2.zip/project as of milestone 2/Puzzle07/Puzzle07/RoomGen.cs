﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Alex Hecht
 * Section 2
 * Random room selector
 * */
namespace Puzzle07
{
    class RoomGen
    {
        //variables contain: total length of the run, total # of possible rooms, holder for randomly generated ints, an array to hold the randomly generated values, and a string to hold the final result
        int runLength;
        const int totalRooms = 8;
        int rholder;
        int[] roomIndex;
        string result;

        //random generator
        Random roll = new Random();

        //basic constructor to get the length of the run
        public RoomGen(int length)
        {
            runLength = length;
        }

        //method that generates the values of each room in the run, in order.  produces values in a string separated by commas
        public string roomsOut()
        {
            //initialize arrray with length of the run
            roomIndex = new int[runLength];


            //loop for length of the run
            for (int y = runLength; y > 0; y--)
            {
                //generate a number and add it into the array, if number is already in the array, regenerate until it is not
                rholder = roll.Next(1, totalRooms+1);

                while (roomIndex.Contains(rholder) == true)
                {
                    rholder = roll.Next(1, totalRooms+1);
                }

                roomIndex[y - 1] = rholder;
            }
            //should convert every value in roomIndex into a string, and join them together with commas
            result = string.Join(",", roomIndex.Select(x => x.ToString()).ToArray());

            return result;

        }

        //method to allow for the generation of a specific room, for testing, and for starting/ending rooms
        public string SpecRoom(int num)
        {
            roomIndex = new int[1];

            roomIndex[0] = num;

            result = string.Join(",", roomIndex.Select(x => x.ToString()).ToArray());

            return result;
        }
    }
}
